package com.practiceCar;

public class Simulated { //1 

	//2
	public static void main(String[] args)  { 
		//4
		Car newCar = new Car();
		newCar.run();
		
	}

}
