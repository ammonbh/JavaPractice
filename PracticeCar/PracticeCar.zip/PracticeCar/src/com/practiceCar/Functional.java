package com.practiceCar;

public interface Functional {
	public String function();
}
